console.log('cote client');
console.log("Je fais d'autres choses en attendant...");
